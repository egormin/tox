from setuptools import setup, find_packages
import helloworld
from os.path import join, dirname

setup(
    name='helloworld',
    version=helloworld.__version__,
    packages=find_packages(),
    include_package_data=True,
    # long_description=open(join(dirname(__file__), 'README.md')).read(),
    test_suite='tests',
    entry_points={
        'console_scripts': [
            'helloworld = helloworld.core:print_message',
            'serve = helloworld.web:run_server',
        ]
    },
    install_requires=[
    'Flask==0.8'
    ]
)
