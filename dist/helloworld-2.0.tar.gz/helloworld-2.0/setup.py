from setuptools import setup, find_packages
import helloworld
from os.path import join, dirname

setup(
    name='helloworld',
    version=helloworld.__version__,
    packages=find_packages(),
    # long_description=open(join(dirname(__file__), 'README.md')).read(),
    entry_points={
        'console_scripts':
            ['helloworld = helloworld.core:print_message']
        }
)